package ar.org.centro8.java.curso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TbjPtc01Application {

	public static void main(String[] args) {
		SpringApplication.run(TbjPtc01Application.class, args);
	}

}
