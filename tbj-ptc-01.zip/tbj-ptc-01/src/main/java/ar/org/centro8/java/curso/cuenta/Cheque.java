package ar.org.centro8.java.curso.cuenta;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Cheque {
    private double monto;
    private String bancoEmisor;
    private LocalDate fechaPago;

}
//El contrutor que habia escrito a mano es exactamente lo que genera @AllArgsContructor.
//lo borre por sino me estaria duplicando.s