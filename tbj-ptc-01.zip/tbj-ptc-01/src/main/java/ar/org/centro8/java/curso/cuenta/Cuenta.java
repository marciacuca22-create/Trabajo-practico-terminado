package ar.org.centro8.java.curso.cuenta;

import ar.org.centro8.java.curso.banco.Cliente;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString // devolucion de los datos del objeto como una cadena de texto.
@RequiredArgsConstructor//crea contructores con los atributos que son final
public abstract class Cuenta {
// clase abstracta no se pueden instanciar objetos directamente de esta clase
// las clases hijas heredan sus atributos y método y pueden implementar sus propios comportamientos.
    private final int numeroCuenta;
    private final Cliente clienteAsociado;
    // atributos finales su valor se asigna al crear la cuenta y no se puede cambiar después
    private double saldo;

    
    // método que permite depositar dinero en la cuenta. No se acepta montos menores o iguales a cero
    // si el monto llega a ser válido, lo suma al saldo actual y muestra el importe depositado y el saldo actualizado
    public void despositarEfectivo(double monto){
        if(monto <= 0){
            System.out.println("La contidad depositada es incorrecta");
            return;//return sirver para devolver un resultado o termina una ejecucion de un metodo.
        } else
            setSaldo(getSaldo()+ monto);
        System.out.println("Se deposito:$"+ monto);
        System.out.println("Su saldo actual es:$"+ getSaldo());
    }
    // método abstracto para extraer dinero de la cuenta. No tiene código propio en esta clase
    // las clases hijas deben implementar su comportamiento
    // devuelve true si la extracción se realiza correctamente o false si no se puede realizar
    public abstract boolean extraerEfectivo(double monto);
}

